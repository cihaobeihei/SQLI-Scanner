#!/bin/bash
#<<<<<<< HEAD
#python sqli_appfinal4.py
#python step3.py
#python phase4.py
scrapy crawl sqli44 > dump
scrapy crawl step3 -s LOG_ENABLED=0
#=======
#reading the file line by line till all opening and closing brackets match[{ }]
# and writing it to another file


#python step1.py
#python step3.py
#python step4.py
#>>>>>>> 28270c2b74375fb747913e59b45ca358dc42c372
